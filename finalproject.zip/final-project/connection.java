import java.io.*;
import java.sql.*;
import java.servlet.http.*;
import javax.servlet.*;
public class Register extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)
	{
		res.setContextType("text/html");
		PrintWriter out=res.getWriter();
		Connection con;
		Statement stmt;
		int userid=0;
		int loginid=0;
		Resultset res1,res2;
		try
		{
			Class.forName("org.postgres.Driver");
			con=DriverManager.getConnection("jdbc:postgresql:turning_roofs","postgres","postgres");
			stmt1=con.createStatement();
			stmt2=con.createStatement();
			userid++;
			loginid++;
			res1=stmt1.executeQuery("insert into buyer values(userid,name,mobile,emailid,address)");
			res2=stmt2.executeQuery("insert into login values(loginid,emailid,password)");
			if(res1==1 && res2==1)
			{
				System.out.println("<html><body>Registered Successfully.! :)</body></html>");
			}
			else
			{
				 System.out.println("<html><body>Registration Failed.! :(</body></html>");
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
